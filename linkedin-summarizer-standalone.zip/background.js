// Minimal background script (not used, but required by manifest) // Empty MV3 service-worker.  Needed only because the manifest requires one.
// If you later need OAuth or alarms you can add logic here.
export {};
